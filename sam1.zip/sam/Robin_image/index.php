<?php
include ('config.php');


if(isset($_POST['submit'])){
    $title = $_POST['name'];
    $folder = "uploads/";
    $image_file=$_FILES['file']['name'];
    $file = $_FILES['file']['tmp_name'];
    $path = $folder . $image_file;  
    $target_file=$folder.basename($image_file);
    $imageFileType=pathinfo($target_file,PATHINFO_EXTENSION);


        if($imageFileType != "jpg" && $imageFileType != "png" && $imageFileType != "jpeg"
        && $imageFileType != "gif" && $imageFileType != "jfif" ) {
        $error[] = 'Sorry, only JPG, JPEG, JFIF, PNG & GIF files are allowed';   
        }
//Set image upload size 
            if ($_FILES["file"]["size"] > 1048576) {
        $error[] = 'Sorry, your image is too large. Upload less than 1 MB KB in size.';
        }

        if(!isset($error))
                {
                    // move image in folder 
                move_uploaded_file($file,$target_file); 
                $image_sql="INSERT INTO `images`(`image`, `title`) VALUES ('$image_file','$title')";
                $result=mysqli_query($conn,$image_sql);
                // $result=mysqli_query($db,"INSERT INTO items(image,title) VALUES('$image_file','$title')"); 
                if($result)
                {
                    header("location:display.php");
                    echo "upload";
                }
                else 
                {
                    echo 'Something went wrong'; 
                }
                }
                }
        if(isset($error)){ 

        foreach ($error as $error) { 
            echo '<div class="message">'.$error.'</div><br>'; 	
        }
        }


?>




<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-KK94CHFLLe+nY2dmCWGMq91rCGa5gtU4mk92HdvYe+M/SXH301p5ILy+dN9+nJOZ" crossorigin="anonymous">

</head>
<body>
    <div class="container py-5">
        <h1 class="text-center">Image Upload</h1>
        
<button class="btn btn-info float-end"><a href="display.php" class="text-white">View Images</a></button> 
       <div class="row my-5">
            <div class="col-md-6 mx-auto">
                    <form method="post" enctype="multipart/form-data">
                        <div class="form-group">
                            <label for="image_upload">Upload Image</label>
                            <input type="file" name="file" class="form-control" id="exampleInputPassword1" placeholder="Password">
                        </div>
                        <div class="form-group">
                            <label for="name">Name</label>
                            <input type="text" name="name" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="Enter email">
                        </div><br><br>
                        <button type="submit" name="submit" class="btn btn-primary">Submit</button>
                    </form>
            </div>
        </div>
    </div>
    
</body>
</html>