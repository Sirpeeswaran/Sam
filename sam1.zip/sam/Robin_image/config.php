<?php
$conn = new mysqli("localhost","root","","image_upload");

?>