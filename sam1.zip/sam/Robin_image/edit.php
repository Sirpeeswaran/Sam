<?php 

include ("config.php"); 
$id=$_GET['id'];


 ?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
   <link rel="stylesheet" type="text/css" href="style.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-KK94CHFLLe+nY2dmCWGMq91rCGa5gtU4mk92HdvYe+M/SXH301p5ILy+dN9+nJOZ" crossorigin="anonymous">
<title></title>
</head>
<body>
	<?php
		if(isset($_POST['update_submit']))
		{	
			$title=$_POST['name'];
            $folder = "uploads/";
            $image_file=$_FILES['file']['name'];
            $file = $_FILES['file']['tmp_name'];
            $path = $folder . $image_file;  
            $target_file=$folder.basename($image_file);
                            $imageFileType=pathinfo($target_file,PATHINFO_EXTENSION);
                if($file!=''){
                //Set image upload size 
                    if ($_FILES["file"]["size"] > 500000) {
                $error[] = 'Sorry, your image is too large. Upload less than 500 KB in size.';
                }
                //Allow only JPG, JPEG, PNG & GIF 
                if($imageFileType != "jpg" && $imageFileType != "png" && $imageFileType != "jpeg"
                && $imageFileType != "gif" && $imageFileType != "jfif" ) {
                $error[] = 'Sorry, only JPG, JPEG, JFIF, PNG & GIF files are allowed';   
                }
                }
                if(!isset($error))
                {
                    if($file!='')
                    {
                        $res=mysqli_query($conn,"SELECT* from `images` WHERE id=$id limit 1");
                if($row=mysqli_fetch_array($res)) 
                {
                $deleteimage=$row['image']; 
                }
                unlink($folder.$deleteimage);
                move_uploaded_file($file,$target_file); 
                $result=mysqli_query($conn,"UPDATE `images` SET image='$image_file',title='$title' WHERE id=$id"); 
                    }
                    else 
                    {
                    $result=mysqli_query($conn,"UPDATE `images` SET title='$title' WHERE id=$id"); 	
                    } 
                if($result)
                {
                header("location:index.php?action=saved");
                }
                else 
                {
                    echo 'Something went wrong'; 
                }
                }
		}


                    if(isset($error)){ 

                    foreach ($error as $error) { 
                        echo '<div class="message">'.$error.'</div><br>'; 	
                    }

                    }

                    $res=mysqli_query($conn,"SELECT* from `images` WHERE id=$id limit 1");
                    if($row=mysqli_fetch_array($res)) 
                    {
                    $image=$row['image']; 
                    $title=$row['title']; 
                    }
	?> 
	<div class="container" style="width:500px;">
		<h1> Edit </h1>
	<?php if(isset($update_sucess))
		{
		echo '<div class="success">Image Updated successfully</div>'; 
		} ?>
<form action="" method="POST" enctype="multipart/form-data">
	<label>Image Preview </label><br>
	<img src="uploads/<?php echo $image;?>" height="100"><br>
	<label>Change Image </label>
	<input type="file" name="file" class="form-control">
	<label>Title</label>
	<input type="text" name="name" value="<?php echo $title;?>" class="form-control">
	<br><br>
	<button name="update_submit" class="btn-primary">Update </button>
</form>
</div>
</body>
</html>