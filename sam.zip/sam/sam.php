<?php

if(isset($_POST['img_submit'])){
    $img_name=$_FILES['img_upload']['name'];
    $img_name2=$_FILES['img_upload2']['name'];
    $tmp_img_name=$_FILES['img_upload']['tmp_name'];
    $tmp_img_name2=$_FILES['img_upload2']['tmp_name'];
    $folder="upload/";
    move_uploaded_file( $tmp_img_name,$folder.$img_name);
    move_uploaded_file( $tmp_img_name2,$folder.$img_name2);
    $conn=new mysqli('localhost','root','sumithra0511','uploadimg');
    $sql="insert into image(img_upload,img_upload2)values('$img_name','$img_name2')";
    $result= mysqli_query($conn,$sql);
    if ($result){
        echo"<script>alert('successfully insert')</script>";
    }
    
}

?>
<form action="" method="POST" enctype="multipart/form-data">
    <input type="file" name="img_upload"><br>
    <input type="file" name="img_upload2"><br>
    <input type="submit" name="img_submit">
</form>
<?php
//   $conn=new mysqli('localhost','root','sumithra0511','uploadimg');
//   $sql="insert into image(img_upload,img_upload2)values('$img_name','$img_name2')";
//   $result= mysqli_query($conn,$sql);    
// echo .$img_name.;
// echo .$img_name2.;


?>