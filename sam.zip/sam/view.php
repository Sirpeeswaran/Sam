<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
<!-- <link rel="stylesheet" type="text/css" href="assets/css/style.css"> -->
<!-- <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-KK94CHFLLe+nY2dmCWGMq91rCGa5gtU4mk92HdvYe+M/SXH301p5ILy+dN9+nJOZ" crossorigin="anonymous"> -->
	<title></title>
    <style>
.container{
    background-color:gray;
    width:100%;
    height:auto;
}

    </style>
</head>
<body>
<div class="container">
<table class="table">
  <thead>
    <tr>
      <th scope="col">SI. NO</th>
      <th scope="col">Title</th>

    </tr>
  </thead>
  <tbody> 


<?php
include ("config.php");
$sql="SELECT * FROM `image` ORDER by id DESC ";
$result=mysqli_query($con,$sql)or die("Error");
while($row=mysqli_fetch_assoc($result)){
    echo '<tr>
<td><a href="upload/'.$row['img_upload'].'" download><img src="upload/'.$row['img_upload'].'"  height="100" width="100"></a>
</td>
<td><a href="edit.php?id='.$row['id'].'"><button class="btn-primary">Edit </button></a>
<a href=\'delete.php?id='.$row['id'].'\' onClick=\'return confirm("Are you sure you want to delete?")\'"><button class="btn-primary btn_del">Delete</button></a>
</td> 



</tr>';
}
?>
</tbody>
</table>
</div>
</body>
</html>