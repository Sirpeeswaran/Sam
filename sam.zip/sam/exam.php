<?php
include ("config.php");
if(isset($_POST['img_submit'])){
    $img_name=$_FILES['img_upload']['name'];
    // $img_name2=$_FILES['img_upload2']['name'];
    $tmp_img_name=$_FILES['img_upload']['tmp_name'];
    // $tmp_img_name2=$_FILES['img_upload2']['tmp_name'];
    $folder="upload/";
    // $path = $folder.$img_name;
    // $target_file=$folder.basename($img_name);
    // $imageFileType=pathinfo($target_file,PATHINFO_EXTENSION);
    // if($imageFileType != "jfif" && $imageFileType !="png" && $imageFileType !="gif"  && $imageFileType !="jpeg"  && $imageFileType !="jpg"){
    //     $error[]='sorry,only below files allowed';
    // }
    // if($_FILES['img_upload']['size']>10387854){
    //     $error[]= 'sorry,your image is too long less than 1MB ';
    // }
    // move_uploaded_file( $tmp_img_name2,$folder.$img_name2);
    $sql="insert into image (img_upload) values('$img_name')";
    $result= mysqli_query($con,$sql);
    if ($result){
        echo"<script>alert('successfully insert')</script>";
        move_uploaded_file( $tmp_img_name,$folder.$img_name);
        header('location:view.php');
    }
}
?>
<form action="" method="POST" enctype="multipart/form-data">
    <input type="file" name="img_upload"><br>
    <!-- <input type="file" name="img_upload2"><br> -->
    <input type="submit" name="img_submit">
</form>



