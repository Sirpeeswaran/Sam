<?php
$con=new mysqli('localhost','root','sumithra0511','uploadimg');
if(!$con){
   die(mysqli_error($con));
}

?>